################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../Key.c \
../Motor.c \
../OLED.c \
../OLED_Data.c \
../PID.c \
../empty.c \
./ti_msp_dl_config.c \
C:/TI/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../gray_detection.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./Key.d \
./Motor.d \
./OLED.d \
./OLED_Data.d \
./PID.d \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./gray_detection.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./Key.o \
./Motor.o \
./OLED.o \
./OLED_Data.o \
./PID.o \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./gray_detection.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"Key.o" \
"Motor.o" \
"OLED.o" \
"OLED_Data.o" \
"PID.o" \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"gray_detection.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"Key.d" \
"Motor.d" \
"OLED.d" \
"OLED_Data.d" \
"PID.d" \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"gray_detection.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../Key.c" \
"../Motor.c" \
"../OLED.c" \
"../OLED_Data.c" \
"../PID.c" \
"../empty.c" \
"./ti_msp_dl_config.c" \
"C:/TI/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../gray_detection.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


