/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000



/* Defines for MOTOR_L */
#define MOTOR_L_INST                                                       TIMA0
#define MOTOR_L_INST_IRQHandler                                 TIMA0_IRQHandler
#define MOTOR_L_INST_INT_IRQN                                   (TIMA0_INT_IRQn)
#define MOTOR_L_INST_CLK_FREQ                                            1000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_L_C0_PORT                                               GPIOB
#define GPIO_MOTOR_L_C0_PIN                                       DL_GPIO_PIN_14
#define GPIO_MOTOR_L_C0_IOMUX                                    (IOMUX_PINCM31)
#define GPIO_MOTOR_L_C0_IOMUX_FUNC                   IOMUX_PINCM31_PF_TIMA0_CCP0
#define GPIO_MOTOR_L_C0_IDX                                  DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_L_C1_PORT                                               GPIOA
#define GPIO_MOTOR_L_C1_PIN                                        DL_GPIO_PIN_3
#define GPIO_MOTOR_L_C1_IOMUX                                     (IOMUX_PINCM8)
#define GPIO_MOTOR_L_C1_IOMUX_FUNC                    IOMUX_PINCM8_PF_TIMA0_CCP1
#define GPIO_MOTOR_L_C1_IDX                                  DL_TIMER_CC_1_INDEX

/* Defines for MOTOR_R */
#define MOTOR_R_INST                                                       TIMG8
#define MOTOR_R_INST_IRQHandler                                 TIMG8_IRQHandler
#define MOTOR_R_INST_INT_IRQN                                   (TIMG8_INT_IRQn)
#define MOTOR_R_INST_CLK_FREQ                                           40000000
/* GPIO defines for channel 0 */
#define GPIO_MOTOR_R_C0_PORT                                               GPIOA
#define GPIO_MOTOR_R_C0_PIN                                        DL_GPIO_PIN_7
#define GPIO_MOTOR_R_C0_IOMUX                                    (IOMUX_PINCM14)
#define GPIO_MOTOR_R_C0_IOMUX_FUNC                   IOMUX_PINCM14_PF_TIMG8_CCP0
#define GPIO_MOTOR_R_C0_IDX                                  DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_MOTOR_R_C1_PORT                                               GPIOA
#define GPIO_MOTOR_R_C1_PIN                                        DL_GPIO_PIN_4
#define GPIO_MOTOR_R_C1_IOMUX                                     (IOMUX_PINCM9)
#define GPIO_MOTOR_R_C1_IOMUX_FUNC                    IOMUX_PINCM9_PF_TIMG8_CCP1
#define GPIO_MOTOR_R_C1_IDX                                  DL_TIMER_CC_1_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMA1)
#define TIMER_0_INST_IRQHandler                                 TIMA1_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMA1_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                         (12499U)




/* Defines for CL: GPIOA.17 with pinCMx 39 on package pin 10 */
#define OLED_CL_PORT                                                     (GPIOA)
#define OLED_CL_PIN                                             (DL_GPIO_PIN_17)
#define OLED_CL_IOMUX                                            (IOMUX_PINCM39)
/* Defines for DA: GPIOB.15 with pinCMx 32 on package pin 3 */
#define OLED_DA_PORT                                                     (GPIOB)
#define OLED_DA_PIN                                             (DL_GPIO_PIN_15)
#define OLED_DA_IOMUX                                            (IOMUX_PINCM32)
/* Port definition for Pin Group Encoder */
#define Encoder_PORT                                                     (GPIOB)

/* Defines for RIGHT_P: GPIOB.4 with pinCMx 17 on package pin 52 */
// pins affected by this interrupt request:["RIGHT_P","LEFT_P"]
#define Encoder_INT_IRQN                                        (GPIOB_INT_IRQn)
#define Encoder_INT_IIDX                        (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define Encoder_RIGHT_P_IIDX                                 (DL_GPIO_IIDX_DIO4)
#define Encoder_RIGHT_P_PIN                                      (DL_GPIO_PIN_4)
#define Encoder_RIGHT_P_IOMUX                                    (IOMUX_PINCM17)
/* Defines for LEFT_P: GPIOB.5 with pinCMx 18 on package pin 53 */
#define Encoder_LEFT_P_IIDX                                  (DL_GPIO_IIDX_DIO5)
#define Encoder_LEFT_P_PIN                                       (DL_GPIO_PIN_5)
#define Encoder_LEFT_P_IOMUX                                     (IOMUX_PINCM18)
/* Defines for RIGHT_D: GPIOB.6 with pinCMx 23 on package pin 58 */
#define Encoder_RIGHT_D_PIN                                      (DL_GPIO_PIN_6)
#define Encoder_RIGHT_D_IOMUX                                    (IOMUX_PINCM23)
/* Defines for LEFT_D: GPIOB.7 with pinCMx 24 on package pin 59 */
#define Encoder_LEFT_D_PIN                                       (DL_GPIO_PIN_7)
#define Encoder_LEFT_D_IOMUX                                     (IOMUX_PINCM24)
/* Defines for CH_0: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GRAY_CH_0_PORT                                                   (GPIOA)
#define GRAY_CH_0_PIN                                           (DL_GPIO_PIN_31)
#define GRAY_CH_0_IOMUX                                           (IOMUX_PINCM6)
/* Defines for CH_1: GPIOA.28 with pinCMx 3 on package pin 35 */
#define GRAY_CH_1_PORT                                                   (GPIOA)
#define GRAY_CH_1_PIN                                           (DL_GPIO_PIN_28)
#define GRAY_CH_1_IOMUX                                           (IOMUX_PINCM3)
/* Defines for CH_2: GPIOA.1 with pinCMx 2 on package pin 34 */
#define GRAY_CH_2_PORT                                                   (GPIOA)
#define GRAY_CH_2_PIN                                            (DL_GPIO_PIN_1)
#define GRAY_CH_2_IOMUX                                           (IOMUX_PINCM2)
/* Defines for CH_3: GPIOA.0 with pinCMx 1 on package pin 33 */
#define GRAY_CH_3_PORT                                                   (GPIOA)
#define GRAY_CH_3_PIN                                            (DL_GPIO_PIN_0)
#define GRAY_CH_3_IOMUX                                           (IOMUX_PINCM1)
/* Defines for CH_4: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GRAY_CH_4_PORT                                                   (GPIOA)
#define GRAY_CH_4_PIN                                           (DL_GPIO_PIN_25)
#define GRAY_CH_4_IOMUX                                          (IOMUX_PINCM55)
/* Defines for CH_5: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GRAY_CH_5_PORT                                                   (GPIOA)
#define GRAY_CH_5_PIN                                           (DL_GPIO_PIN_24)
#define GRAY_CH_5_IOMUX                                          (IOMUX_PINCM54)
/* Defines for CH_6: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GRAY_CH_6_PORT                                                   (GPIOB)
#define GRAY_CH_6_PIN                                           (DL_GPIO_PIN_24)
#define GRAY_CH_6_IOMUX                                          (IOMUX_PINCM52)
/* Defines for CH_7: GPIOB.23 with pinCMx 51 on package pin 22 */
#define GRAY_CH_7_PORT                                                   (GPIOB)
#define GRAY_CH_7_PIN                                           (DL_GPIO_PIN_23)
#define GRAY_CH_7_IOMUX                                          (IOMUX_PINCM51)
/* Defines for CH_8: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GRAY_CH_8_PORT                                                   (GPIOB)
#define GRAY_CH_8_PIN                                           (DL_GPIO_PIN_19)
#define GRAY_CH_8_IOMUX                                          (IOMUX_PINCM45)
/* Defines for CH_9: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GRAY_CH_9_PORT                                                   (GPIOB)
#define GRAY_CH_9_PIN                                           (DL_GPIO_PIN_18)
#define GRAY_CH_9_IOMUX                                          (IOMUX_PINCM44)
/* Defines for CH_10: GPIOB.16 with pinCMx 33 on package pin 4 */
#define GRAY_CH_10_PORT                                                  (GPIOB)
#define GRAY_CH_10_PIN                                          (DL_GPIO_PIN_16)
#define GRAY_CH_10_IOMUX                                         (IOMUX_PINCM33)
/* Defines for CH_11: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GRAY_CH_11_PORT                                                  (GPIOB)
#define GRAY_CH_11_PIN                                          (DL_GPIO_PIN_13)
#define GRAY_CH_11_IOMUX                                         (IOMUX_PINCM30)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_MOTOR_L_init(void);
void SYSCFG_DL_MOTOR_R_init(void);
void SYSCFG_DL_TIMER_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
